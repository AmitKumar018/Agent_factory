# Architecture Specification

## Summary
A document-grounded planning workflow that turns approved requirements into an approved architecture and executable task plan.

## Components

### Authenticated Planning API
- **Role**: Receives approved requirements and exposes status, tasks, and research.
- **Pattern References**: Router
- **Tools**: FastAPI, SQLAlchemy
- **Interacts With**: Planning Graph, Artifact Store

### Document RAG Research
- **Role**: Retrieves project-scoped document chunks and cites sections.
- **Pattern References**: RAG
- **Tools**: ChromaDB, DocumentChunk
- **Interacts With**: Pattern KB Research, Architecture Generator

### Pattern KB Research
- **Role**: Looks up global agentic patterns and snapshots selected guidance.
- **Pattern References**: RAG, Tool-Use
- **Tools**: Pattern DB, ChromaDB
- **Interacts With**: Pattern Selector, Planner

### Planning Graph
- **Role**: Builds architecture and ordered tasks with a critic loop.
- **Pattern References**: Planner-Executor, Reflection
- **Tools**: LangGraph
- **Interacts With**: HITL Approval, Task Store

### HITL Approval and SSE
- **Role**: Pauses for approve/reject, resumes through Command(resume=...), and emits replayable events.
- **Pattern References**: Tool-Use, Reflection
- **Tools**: WebSocket, SSE, SQLite checkpointer
- **Interacts With**: Planning Graph, Run Event Log

## Data Flow
Approved requirements load from Workflow 1, selected patterns are snapshotted, document and Pattern KB findings ground architecture, planner emits ordered tasks, critic validates coverage, and HITL approval persists artifacts.

## Agent Topology
Router plus planner-executor with reflection; complex inputs add RAG/KB/web-stub research before architecture and planning.

## Tool Inventory
- FastAPI
- LangGraph
- SQLite
- ChromaDB
- FileStore
- SSE
- WebSocket HITL

## Deployment Notes
Runs persist to SQLite and local artifacts under the project run directory; web search remains a replaceable stub until external access is configured.

## Risks
- Generated plans depend on document parse quality.
- The in-memory HITL queue is single-process only.
- Web research is stubbed without network-enabled tooling.

## Pattern References
- Planner-Executor
- RAG
- Reflection
- Hierarchical Agents
- Tool-Use