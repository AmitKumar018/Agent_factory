# Architecture Overview

This document provides a detailed overview of the architecture for a document-grounded planning workflow. The system is designed to transform approved requirements into an approved architecture and executable task plan.

## Summary

The architecture is centered around a document-grounded planning workflow that processes approved requirements into a structured plan. The plan is then executed in a controlled manner, ensuring that each step is inspectable and serializable.

## Components

### Authenticated Planning API
- **Role**: Receives approved requirements and exposes status, tasks, and research.
- **Patterns**: Router
- **Tools**: FastAPI, SQLAlchemy
- **Interactions**: Planning Graph, Artifact Store

### Document RAG Research
- **Role**: Retrieves project-scoped document chunks and cites sections.
- **Patterns**: RAG
- **Tools**: ChromaDB, DocumentChunk
- **Interactions**: Pattern KB Research, Architecture Generator

### Pattern KB Research
- **Role**: Looks up global agentic patterns and snapshots selected guidance.
- **Patterns**: RAG, Tool-Use
- **Tools**: Pattern DB, ChromaDB
- **Interactions**: Pattern Selector, Planner

### Planning Graph
- **Role**: Builds architecture and ordered tasks with a critic loop.
- **Patterns**: Planner-Executor, Reflection
- **Tools**: LangGraph
- **Interactions**: HITL Approval, Task Store

### HITL Approval and SSE
- **Role**: Pauses for approve/reject, resumes through Command(resume=...), and emits replayable events.
- **Patterns**: Tool-Use, Reflection
- **Tools**: WebSocket, SSE, SQLite checkpointer
- **Interactions**: Planning Graph, Run Event Log

## Data Flow

Approved requirements are loaded from Workflow 1. Selected patterns are snapshotted, and document and Pattern KB findings ground the architecture. The planner emits ordered tasks, the critic validates coverage, and HITL approval persists artifacts.

## Agent Topology

The system uses a router plus planner-executor with reflection. Complex inputs add RAG/KB/web-stub research before architecture and planning.

## Tool Inventory

- FastAPI
- LangGraph
- SQLite
- ChromaDB
- FileStore
- SSE
- WebSocket HITL

## Deployment Notes

Runs persist to SQLite and local artifacts under the project run directory. Web search remains a replaceable stub until external access is configured.

## Risks

- Generated plans depend on document parse quality.
- The in-memory HITL queue is single-process only.
- Web research is stubbed without network-enabled tooling.

## Pattern References

- Planner-Executor
- RAG
- Reflection
- Hierarchical Agents
- Tool-Use